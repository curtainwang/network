/* cnaiapi_win32.h */

#include <io.h>
#define read  _read
#define write _write
#define STDIN_FILENO  0
#define STDOUT_FILENO 1
